<?php

$trainstations = [
    'Frauenfeld',
    'Winterthur',
    'Romanshorn',
    'Arbon',
    'St.Gallen'
];

?>