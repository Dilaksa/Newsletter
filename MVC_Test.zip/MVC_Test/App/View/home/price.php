<?php
$prices = [
    '1' => [
        'From' => 'Arbon',
        'To' => 'St.Gallen',
        'Price' => '9.60'
    ],
    '2' => [
        'From' => 'Frauenfeld',
        'To' => 'Winterthur',
        'Price' => '3.60'
    ]
];
?>