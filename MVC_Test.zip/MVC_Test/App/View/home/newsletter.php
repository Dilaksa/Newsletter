<form action="/MVC_Test/public/home/newsletter" method="POST">

<input type="text" name="mail">
<input type="submit">

</form>